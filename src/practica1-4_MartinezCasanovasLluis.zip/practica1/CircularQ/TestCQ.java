package practica1.CircularQ;

import java.util.Iterator;

public class TestCQ {

    public static void main(String[] args) {
        throw new RuntimeException("Aquest mètode s'ha de completar...");

    }
}

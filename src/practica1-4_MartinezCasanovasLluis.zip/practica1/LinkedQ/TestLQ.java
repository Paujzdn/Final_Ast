package practica1.LinkedQ;

import java.util.Iterator;

public class TestLQ {

    public static void main(String[] args) {
        throw new RuntimeException("Aquest mètode s'ha de completar...");

    }
}
